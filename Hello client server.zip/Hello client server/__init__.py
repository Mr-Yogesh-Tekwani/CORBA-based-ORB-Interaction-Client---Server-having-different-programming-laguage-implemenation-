import omniORB
omniORB.updateModule("HelloApp__POA")

# ** 1. Stub files contributing to this module
import Hello_idl
